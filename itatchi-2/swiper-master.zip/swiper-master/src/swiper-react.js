import { Swiper } from './react/swiper';
import { SwiperSlide } from './react/swiper-slide';

export { Swiper, SwiperSlide };
